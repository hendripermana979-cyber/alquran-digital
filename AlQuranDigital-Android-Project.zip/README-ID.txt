AL-QUR'AN DIGITAL - PROYEK ANDROID WEBVIEW

Proyek ini membungkus aplikasi HTML yang disediakan menjadi APK Android.
Build APK dilakukan gratis melalui GitHub Actions (perlu akun GitHub dan internet).

LANGKAH:
1. Ekstrak ZIP ini di HP.
2. Buka https://github.com dan masuk/daftar.
3. Buat repository baru, misalnya al-quran-digital-apk.
4. Pilih Add file > Upload files.
5. Upload SEMUA isi folder proyek ini (termasuk folder .github).
6. Commit ke branch main.
7. Buka tab Actions pada repository.
8. Pilih workflow "Build APK", lalu tekan Run workflow.
9. Tunggu sampai selesai (tanda centang hijau).
10. Buka hasil workflow, bagian Artifacts, unduh "Al-Quran-Digital-APK".
11. Ekstrak file artifact jika berupa ZIP. Instal app-debug.apk di HP.

CATATAN:
- APK ini adalah versi debug untuk instalasi/pratinjau pribadi, bukan rilis Play Store.
- Aplikasi memerlukan internet untuk API jadwal sholat dan data surat.
- Data riwayat/tema tersimpan di penyimpanan WebView pada perangkat.
- File HTML asli disimpan di app/src/main/assets/www/.
