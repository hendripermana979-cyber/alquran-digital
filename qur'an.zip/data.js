// Data Titik Awal 30 Juz Al-Qur'an
const DATA_30_JUZ = [
  { juz: 1, surah: 1, ayat: 1, ket: "Al-Fatihah Ayat 1" },
  { juz: 2, surah: 2, ayat: 142, ket: "Al-Baqarah Ayat 142" },
  { juz: 3, surah: 2, ayat: 253, ket: "Al-Baqarah Ayat 253" },
  { juz: 4, surah: 3, ayat: 93, ket: "Ali 'Imran Ayat 93" },
  { juz: 5, surah: 4, ayat: 24, ket: "An-Nisa' Ayat 24" },
  { juz: 6, surah: 4, ayat: 148, ket: "An-Nisa' Ayat 148" },
  { juz: 7, surah: 5, ayat: 82, ket: "Al-Ma'idah Ayat 82" },
  { juz: 8, surah: 6, ayat: 111, ket: "Al-An'am Ayat 111" },
  { juz: 9, surah: 7, ayat: 88, ket: "Al-A'raf Ayat 88" },
  { juz: 10, surah: 8, ayat: 41, ket: "Al-Anfal Ayat 41" },
  { juz: 11, surah: 9, ayat: 93, ket: "At-Taubah Ayat 93" },
  { juz: 12, surah: 11, ayat: 6, ket: "Hud Ayat 6" },
  { juz: 13, surah: 12, ayat: 53, ket: "Yusuf Ayat 53" },
  { juz: 14, surah: 15, ayat: 1, ket: "Al-Hijr Ayat 1" },
  { juz: 15, surah: 17, ayat: 1, ket: "Al-Isra' Ayat 1" },
  { juz: 16, surah: 18, ayat: 75, ket: "Al-Kahf Ayat 75" },
  { juz: 17, surah: 21, ayat: 1, ket: "Al-Anbiya' Ayat 1" },
  { juz: 18, surah: 23, ayat: 1, ket: "Al-Mu'minun Ayat 1" },
  { juz: 19, surah: 25, ayat: 21, ket: "Al-Furqan Ayat 21" },
  { juz: 20, surah: 27, ayat: 56, ket: "An-Naml Ayat 56" },
  { juz: 21, surah: 29, ayat: 46, ket: "Al-'Ankabut Ayat 46" },
  { juz: 22, surah: 33, ayat: 31, ket: "Al-Ahzab Ayat 31" },
  { juz: 23, surah: 36, ayat: 28, ket: "Yasin Ayat 28" },
  { juz: 24, surah: 39, ayat: 32, ket: "Az-Zumar Ayat 32" },
  { juz: 25, surah: 41, ayat: 47, ket: "Fussilat Ayat 47" },
  { juz: 26, surah: 46, ayat: 1, ket: "Al-Ahqaf Ayat 1" },
  { juz: 27, surah: 51, ayat: 31, ket: "Az-Zariyat Ayat 31" },
  { juz: 28, surah: 58, ayat: 1, ket: "Al-Mujadilah Ayat 1" },
  { juz: 29, surah: 67, ayat: 1, ket: "Al-Mulk Ayat 1" },
  { juz: 30, surah: 78, ayat: 1, ket: "An-Naba' Ayat 1" }
];

// Data Doa-Doa Muslim & Wudhu
const DATA_DOA_MUSLIM = [
  {
    judul: "Niat Wudhu",
    arab: "نَوَيْتُ الْوُضُوْءَ لِرَفْعِ الْحَدَثِ الْاَصْغَرِ فَرْضًا لِلّٰهِ تَعَالَى",
    latin: "Nawaitul whudu-a liraf'il hadatsil asghari fardhan lillaahi ta'aalaa.",
    arti: "Aku niat berwudhu untuk menghilangkan hadats kecil fardhu karena Allah Ta'ala."
  },
  {
    judul: "Doa Setelah Wudhu",
    arab: "اَشْهَدُ اَنْ لَآ اِلٰهَ اِلَّا اللّٰهُ وَحْدَهُ لَا شَرِيْكَ لَهُ وَاَشْهَدُ اَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُوْلُهُ، اَللّٰهُمَّ اجْعَلْنِيْ مِنَ التَّوَّابِيْنَ وَاجْعَلْنِيْ مِنَ الْمُتَطَهِّرِيْنَ",
    latin: "Asyhadu allaa ilaaha illallaah wahdahuu laa syariikalahu wa asyhadu anna muhammadan 'abduhuu wa rasuuluhuu. Allaahummaj'alnii minat-tawwaabiina waj'alnii minal-mutathahhiriin.",
    arti: "Aku bersaksi tiada Tuhan selain Allah Yang Maha Esa dan tiada sekutu bagi-Nya, dan aku bersaksi bahwa Nabi Muhammad adalah hamba dan utusan-Nya. Ya Allah, jadikanlah aku termasuk orang-orang yang bertaubat dan bersuci."
  },
  {
    judul: "Doa Taubat (Sayyidul Istighfar)",
    arab: "اَللّٰهُمَّ أَنْتَ رَبِّيْ لَا إِلٰهَ إِلَّا أَنْتَ خَلَقْتَنِيْ وَأَنَا عَبْدُكَ وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوْذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوْءُ لَكَ بِنِعْمَتِكَ عَلَيَّ وَأَبُوْءُ بِذَنْبِيْ فَاغْفِرْ لِيْ فَإِنَّهُ لَا يَغْفِرُ الذُّنُوْبَ إِلَّا أَنْتَ",
    latin: "Allaahumma anta rabbii laa ilaaha illaa anta khalaqtanii wa anaa 'abduka wa anaa 'alaa 'ahdika wa wa'dika mastatha'tu, a'uudzu bika min syarri maa shana'tu, abuu-u laka bini'matika 'alayya wa abuu-u bidzanbii faghfir lii fa-innahuu laa yaghfirudz-dzunuuba illaa anta.",
    arti: "Ya Allah, Engkau adalah Tuhanku, tiada Tuhan selain Engkau. Engkau telah menciptakanku dan aku adalah hamba-Mu. Aku berada di atas perjanjian-Mu semampuku. Aku berlindung kepada-Mu dari keburukan perbuatanku. Aku mengakui nikmat-Mu kepadaku dan mengakui dosaku, maka ampunilah aku, karena tiada yang dapat mengampuni dosa selain Engkau."
  },
  {
    judul: "Doa Sebelum Tidur",
    arab: "بِسْمِكَ اللّٰهُمَّ اَحْيَا وَاَمُوْتُ",
    latin: "Bismikallaahumma ahyaa wa amuut.",
    arti: "Dengan menyebut nama-Mu ya Allah, aku hidup dan aku mati."
  },
  {
    judul: "Doa Sapu Jagat (Kebaikan Dunia & Akhirat)",
    arab: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
    latin: "Rabbanaa aatinaa fid-dunyaa hasanatan wa fil-aakhirati hasanatan wa qinaa 'adzaaban-naar.",
    arti: "Ya Tuhan kami, berilah kami kebaikan di dunia dan kebaikan di akhirat, serta lindungilah kami dari siksa api neraka."
  }
];

// Data Tuntunan Sholat Wajib & Sunnah Lengkap (Niat sampai Salam)
const DATA_TUNTUNAN_SHOLAT = {
  wajib: [
    {
      judul: "1. Niat Sholat Subuh (2 Rakaat)",
      arab: "اُصَلِّى فَرْضَ الصُّبْحِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً لِلّٰهِ تَعَالَى",
      latin: "Ushalli fardhash-shubhi rak'ataini mustaqbilal qiblati adaa-an lillaahi ta'aalaa.",
      arti: "Aku niat melakukan sholat fardhu Subuh 2 rakaat menghadap kiblat karena Allah Ta'ala."
    },
    {
      judul: "2. Niat Sholat Dzuhur (4 Rakaat)",
      arab: "اُصَلِّى فَرْضَ الظُّهْرِ اَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً لِلّٰهِ تَعَالَى",
      latin: "Ushalli fardhadz-dzuhri arba'a raka'aatin mustaqbilal qiblati adaa-an lillaahi ta'aalaa.",
      arti: "Aku niat melakukan sholat fardhu Dzuhur 4 rakaat menghadap kiblat karena Allah Ta'ala."
    },
    {
      judul: "3. Niat Sholat Ashar (4 Rakaat)",
      arab: "اُصَلِّى فَرْضَ الْعَصْرِ اَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً لِلّٰهِ تَعَالَى",
      latin: "Ushalli fardhal 'ashri arba'a raka'aatin mustaqbilal qiblati adaa-an lillaahi ta'aalaa.",
      arti: "Aku niat melakukan sholat fardhu Ashar 4 rakaat menghadap kiblat karena Allah Ta'ala."
    },
    {
      judul: "4. Niat Sholat Maghrib (3 Rakaat)",
      arab: "اُصَلِّى فَرْضَ الْمَغْرِبِ ثَلَاثَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً لِلّٰهِ تَعَالَى",
      latin: "Ushalli fardhal maghribi tsalaatsa raka'aatin mustaqbilal qiblati adaa-an lillaahi ta'aalaa.",
      arti: "Aku niat melakukan sholat fardhu Maghrib 3 rakaat menghadap kiblat karena Allah Ta'ala."
    },
    {
      judul: "5. Niat Sholat Isya (4 Rakaat)",
      arab: "اُصَلِّى فَرْضَ الْعِشَاءِ اَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً لِلّٰهِ تَعَالَى",
      latin: "Ushalli fardhal 'isyaa-i arba'a raka'aatin mustaqbilal qiblati adaa-an lillaahi ta'aalaa.",
      arti: "Aku niat melakukan sholat fardhu Isya 4 rakaat menghadap kiblat karena Allah Ta'ala."
    }
  ],
  sunnah: [
    {
      judul: "Niat Sholat Sunnah Dhuha (2 Rakaat)",
      arab: "اُصَلِّى سُنَّةَ الضُّحَى رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً لِلّٰهِ تَعَالَى",
      latin: "Ushalli sunnatadh-dhuhaa rak'ataini mustaqbilal qiblati adaa-an lillaahi ta'aalaa.",
      arti: "Aku niat sholat sunnah Dhuha 2 rakaat menghadap kiblat karena Allah Ta'ala."
    },
    {
      judul: "Niat Sholat Sunnah Tahajud (2 Rakaat)",
      arab: "اُصَلِّى سُنَّةَ التَّهَجُّدِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً لِلّٰهِ تَعَالَى",
      latin: "Ushalli sunnatat-tahajjudi rak'ataini mustaqbilal qiblati adaa-an lillaahi ta'aalaa.",
      arti: "Aku niat sholat sunnah Tahajud 2 rakaat menghadap kiblat karena Allah Ta'ala."
    },
    {
      judul: "Niat Sholat Sunnah Taubat (2 Rakaat)",
      arab: "اُصَلِّى سُنَّةَ التَّوْبَةِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً لِلّٰهِ تَعَالَى",
      latin: "Ushalli sunnatat-taubati rak'ataini mustaqbilal qiblati adaa-an lillaahi ta'aalaa.",
      arti: "Aku niat sholat sunnah Taubat 2 rakaat menghadap kiblat karena Allah Ta'ala."
    },
    {
      judul: "Niat Sholat Sunnah Witir (1 Rakaat Penutup)",
      arab: "اُصَلِّى سُنَّةَ الْوِتْرِ رَكْعَةً مُسْتَقْبِلَ الْقِبْلَةِ اَدَاءً لِلّٰهِ تَعَالَى",
      latin: "Ushalli sunnatal witri rak'atan mustaqbilal qiblati adaa-an lillaahi ta'aalaa.",
      arti: "Aku niat sholat sunnah Witir 1 rakaat menghadap kiblat karena Allah Ta'ala."
    }
  ],
  gerakanLengkap: [
    {
      judul: "Langkah 1: Takbiratul Ihram & Doa Iftitah",
      arab: "اَللّٰهُ اَكْبَرُ كَبِيْرًا وَالْحَمْدُ لِلّٰهِ كَثِيْرًا وَسُبْحَانَ اللّٰهِ بُكْرَةً وَاَصِيْلًا. اِنِّى وَجَّهْتُ وَجْهِيَ لِلَّذِيْ فَطَرَ السَّمٰوَاتِ وَالْاَرْضَ حَنِيْفًا مُسْلِمًا وَمَا اَنَا مِنَ الْمُشْرِكِيْنَ",
      latin: "Allaahu akbar kabiiraa walhamdu lillaahi katsiiraa wa subhaanallaahi bukrataw wa ashiilaa. Innii wajjahtu wajhiya lilladzii fatharas-samaawaati wal-ardha haniifam muslimaw wa maa anaa minal-musyrikiin.",
      arti: "Allah Maha Besar dengan sebesar-besarnya, segala puji bagi Allah dengan pujian yang banyak. Sesungguhnya aku menghadapkan wajahku kepada Tuhan yang menciptakan langit dan bumi dengan lurus dan berserah diri."
    },
    {
      judul: "Langkah 2: Membaca Surat Al-Fatihah (Wajib Tiap Rakaat)",
      arab: "بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ ۝ اَلْحَمْدُ لِلّٰهِ رَبِّ الْعٰلَمِيْنَ ۝ الرَّحْمٰنِ الرَّحِيْمِ ۝ مٰلِكِ يَوْمِ الدِّيْنِ ۝ اِيَّاكَ نَعْبُدُ وَاِيَّاكَ نَسْتَعِيْنُ ۝ اِهْدِنَا الصِّرَاطَ الْمُسْتَقِيْمَ ۝ صِرَاطَ الَّذِيْنَ اَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوْبِ عَلَيْهِمْ وَلَا الضَّاۤلِّيْنَ",
      latin: "Bismillaahir-rahmaanir-rahiim. Alhamdu lillaahi rabbil 'aalamiin. Ar-rahmaanir-rahiim. Maaliki yaumid-diin. Iyyaaka na'budu wa iyyaaka nasta'iin. Ihdinash-shiraathal mustaqiim. Shiraathal-ladziina an'amta 'alaihim ghairil maghdhuubi 'alaihim wa ladh-dhaalliin.",
      arti: "Dengan nama Allah Yang Maha Pengasih lagi Maha Penyayang. Segala puji bagi Allah Tuhan seluruh alam..."
    },
    {
      judul: "Langkah 3: Rukuk (3x)",
      arab: "سُبْحَانَ رَبِّيَ الْعَظِيْمِ وَبِحَمْدِهِ",
      latin: "Subhaana rabbiyal 'azhiimi wa bihamdih (3x).",
      arti: "Maha Suci Tuhanku Yang Maha Agung dan dengan memuji-Nya."
    },
    {
      judul: "Langkah 4: I'tidal (Bangkit dari Rukuk)",
      arab: "سَمِعَ اللّٰهُ لِمَنْ حَمِدَهُ، رَبَّنَا لَكَ الْحَمْدُ مِلْءَ السَّمٰوَاتِ وَمِلْءَ الْاَرْضِ وَمِلْءَ مَا شِئْتَ مِنْ شَيْءٍ بَعْدُ",
      latin: "Sami'allaahu liman hamidah. Rabbanaa lakal hamdu mil-us-samaawaati wa mil-ul-ardhi wa mil-u maa syi'ta min syai-in ba'du.",
      arti: "Allah Maha Mendengar orang yang memuji-Nya. Ya Tuhan kami, bagi-Mu segala puji sepenuh langit dan bumi."
    },
    {
      judul: "Langkah 5: Sujud (3x)",
      arab: "سُبْحَانَ رَبِّيَ الْاَعْلٰى وَبِحَمْدِهِ",
      latin: "Subhaana rabbiyal a'laa wa bihamdih (3x).",
      arti: "Maha Suci Tuhanku Yang Maha Tinggi dan dengan memuji-Nya."
    },
    {
      judul: "Langkah 6: Duduk di Antara Dua Sujud",
      arab: "رَبِّ اغْفِرْ لِيْ وَارْحَمْنِيْ وَاجْبُرْنِيْ وَارْفَعْنِيْ وَارْزُقْنِيْ وَاهْدِنِيْ وَعَافِنِيْ وَاعْفُ عَنِّيْ",
      latin: "Rabbighfir lii warhamnii wajburnii warfa'nii warzuqnii wahdinii wa 'aafinii wa'fu 'annii.",
      arti: "Ya Tuhanku, ampunilah aku, rahmatilah aku, cukupkanlah kekuranganku, angkatlah derajatku, berilah aku rezeki, berilah aku petunjuk, sehatkanlah aku, dan maafkanlah aku."
    },
    {
      judul: "Langkah 7: Tasyahud Akhir",
      arab: "اَلتَّحِيَّاتُ الْمُبَارَكَاتُ الصَّلَوَاتُ الطَّيِّبَاتُ لِلّٰهِ، اَلسَّلَامُ عَلَيْكَ اَيُّهَا النَّبِيُّ وَرَحْمَةُ اللّٰهِ وَبَرَكَاتُهُ، اَلسَّلَامُ عَلَيْنَا وَعَلَى عِبَادِ اللّٰهِ الصَّالِحِيْنَ، اَشْهَدُ اَنْ لَآ اِلٰهَ اِلَّا اللّٰهُ وَاَشْهَدُ اَنَّ مُحَمَّدًا رَسُوْلُ اللّٰهِ، اَللّٰهُمَّ صَلِّ عَلٰى سَيِّدِنَا مُحَمَّدٍ وَعَلٰى اٰلِ سَيِّدِنَا مُحَمَّدٍ",
      latin: "At-tahiyyaatul mubaarakaatush-shalawaatuth-thayyibaatu lillaah. As-salaamu 'alaika ayyuhan-nabiyyu wa rahmatullaahi wa barakaatuh. As-salaamu 'alainaa wa 'alaa 'ibaadillaahish-shaalihiin. Asyhadu allaa ilaaha illallaah wa asyhadu anna muhammadar-rasuulullaah. Allaahumma shalli 'alaa sayyidinaa muhammad wa 'alaa aali sayyidinaa muhammad.",
      arti: "Segala kehormatan, keberkahan, rahmat dan kebaikan adalah milik Allah. Semoga keselamatan tercurah kepadamu wahai Nabi, beserta rahmat dan berkah Allah..."
    },
    {
      judul: "Langkah 8: Salam (Menoleh Kanan & Kiri)",
      arab: "اَلسَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللّٰهِ",
      latin: "As-salaamu 'alaikum wa rahmatullaah.",
      arti: "Semoga keselamatan dan rahmat Allah terlimpah kepadamu."
    }
  ]
};