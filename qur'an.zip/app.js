let semuaSurat = [];
let daftarAyatAktif = [];
let indeksAyatDiputar = -1;
let sedangPutarBeruntun = false;
let subTabQuran = 'surat';
let suratAktifInfo = null;
let suratSedangDiputar = null;

const audio = document.getElementById('audioGlobal');

// ==========================================
// 0. PENGATURAN TEMA (DEFAULT & LANGIT MALAM KARTUN)
// ==========================================
function inisialisasiTema() {
  const temaTersimpan = localStorage.getItem('temaPilihan') || 'default';
  terapkanTema(temaTersimpan);
}

function toggleTema() {
  const saatIniKartun = document.body.classList.contains('tema-kartun');
  const temaBaru = saatIniKartun ? 'default' : 'kartun';
  localStorage.setItem('temaPilihan', temaBaru);
  terapkanTema(temaBaru);
}

function terapkanTema(namaTema) {
  const label = document.getElementById('labelTema');
  if (namaTema === 'kartun') {
    document.body.classList.remove('tema-default');
    document.body.classList.add('tema-kartun');
    if (label) label.textContent = 'Mode Default';
  } else {
    document.body.classList.remove('tema-kartun');
    document.body.classList.add('tema-default');
    if (label) label.textContent = 'Mode Kartun';
  }
}

// ==========================================
// 1. NAVIGASI UTAMA (AUDIO TETAP JALAN DI LATAR BELAKANG)
// ==========================================
function bukaMenu(namaMenu) {
  // hentikanSemuaAudio() dihapus dari sini agar suara terus berjalan saat pindah tab
  document.querySelectorAll('.halaman').forEach(el => el.classList.remove('aktif'));
  document.getElementById(`view-${namaMenu}`).classList.add('aktif');

  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.classList.toggle('aktif', btn.dataset.target === namaMenu);
  });

  if (namaMenu === 'history') renderHistory();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ==========================================
// 2. JADWAL SHOLAT REAL-TIME (KEMENAG RI)
// ==========================================
async function muatJadwalSholat() {
  const kota = document.getElementById('inputKota').value.trim() || 'Bandung';
  const wadah = document.getElementById('wadahJadwalSholat');
  const infoTgl = document.getElementById('infoTanggalSholat');
  wadah.innerHTML = `<div class="status-teks">Memuat jadwal ${kota}...</div>`;

  try {
    const url = `https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(kota)}&country=Indonesia&method=20`;
    const res = await fetch(url);
    const json = await res.json();
    if (json.code !== 200) throw new Error('Kota tidak ditemukan');

    const t = json.data.timings;
    infoTgl.textContent = `${kota} • ${json.data.date.readable}`;

    wadah.innerHTML = `
      <div class="item-waktu"><span>Subuh</span><strong>${t.Fajr}</strong></div>
      <div class="item-waktu"><span>Dzuhur</span><strong>${t.Dhuhr}</strong></div>
      <div class="item-waktu"><span>Ashar</span><strong>${t.Asr}</strong></div>
      <div class="item-waktu"><span>Maghrib</span><strong>${t.Maghrib}</strong></div>
      <div class="item-waktu"><span>Isya</span><strong>${t.Isha}</strong></div>
    `;
  } catch (e) {
    wadah.innerHTML = `<div class="status-teks">Gagal memuat jadwal sholat. Periksa nama kota atau internet.</div>`;
  }
}

// ==========================================
// 3. AL-QUR'AN: 114 SURAT & 30 JUZ
// ==========================================
async function muatDaftarSurat() {
  const wadah = document.getElementById('daftarQuran');
  wadah.innerHTML = `<div class="status-teks">Memuat 114 Surat...</div>`;
  try {
    const res = await fetch('https://equran.id/api/v2/surat');
    const json = await res.json();
    semuaSurat = json.data;
    renderDaftarSurat(semuaSurat);
  } catch (e) {
    wadah.innerHTML = `<div class="status-teks">Gagal terhubung ke server Al-Qur'an.</div>`;
  }
}

function renderDaftarSurat(list) {
  const wadah = document.getElementById('daftarQuran');
  wadah.innerHTML = '';
  list.forEach(s => {
    const div = document.createElement('div');
    div.className = 'kartu-daftar btn-interaktif';
    div.onclick = () => bukaBacaSurat(s.nomor, 1);
    div.innerHTML = `
      <div style="display:flex; align-items:center; gap:12px;">
        <div class="nomor-bulat">${s.nomor}</div>
        <div>
          <strong style="font-size:0.95rem;">${s.namaLatin}</strong><br>
          <small style="color:var(--teks-redup); font-size:0.75rem;">${s.arti} • ${s.jumlahAyat} Ayat</small>
        </div>
      </div>
      <div class="teks-arab-kecil">${s.nama}</div>
    `;
    wadah.appendChild(div);
  });
}

function renderDaftarJuz(list) {
  const wadah = document.getElementById('daftarQuran');
  wadah.innerHTML = '';
  list.forEach(j => {
    const div = document.createElement('div');
    div.className = 'kartu-daftar btn-interaktif';
    div.onclick = () => bukaBacaSurat(j.surah, j.ayat);
    div.innerHTML = `
      <div style="display:flex; align-items:center; gap:12px;">
        <div class="nomor-bulat">${j.juz}</div>
        <div>
          <strong style="font-size:0.95rem;">Juz ${j.juz}</strong><br>
          <small style="color:var(--teks-redup); font-size:0.75rem;">Mulai: ${j.ket}</small>
        </div>
      </div>
      <span style="color:var(--aksen-utama); font-size:0.82rem; font-weight:600;">Baca →</span>
    `;
    wadah.appendChild(div);
  });
}

function gantiSubTabQuran(tab) {
  subTabQuran = tab;
  document.getElementById('btnTabSurat').classList.toggle('aktif', tab === 'surat');
  document.getElementById('btnTabJuz').classList.toggle('aktif', tab === 'juz');
  document.getElementById('cariQuran').value = '';
  tab === 'surat' ? renderDaftarSurat(semuaSurat) : renderDaftarJuz(DATA_30_JUZ);
}

function filterQuran() {
  const q = document.getElementById('cariQuran').value.toLowerCase().trim();
  if (subTabQuran === 'surat') {
    renderDaftarSurat(semuaSurat.filter(s =>
      s.namaLatin.toLowerCase().includes(q) || s.arti.toLowerCase().includes(q) || String(s.nomor) === q
    ));
  } else {
    renderDaftarJuz(DATA_30_JUZ.filter(j =>
      `juz ${j.juz}`.includes(q) || j.ket.toLowerCase().includes(q)
    ));
  }
}

// ==========================================
// 4. BACA SURAT & AUDIO BERUNTUN DI LATAR BELAKANG
// ==========================================
async function bukaBacaSurat(nomorSurat, ayatTujuan = 1) {
  document.getElementById('quran-list-mode').style.display = 'none';
  document.getElementById('quran-read-mode').style.display = 'block';
  window.scrollTo({ top: 0 });

  const wadahAyat = document.getElementById('wadahAyat');
  wadahAyat.innerHTML = `<div class="status-teks">Memuat ayat...</div>`;
  document.getElementById('bismillahHeader').style.display = (nomorSurat === 1 || nomorSurat === 9) ? 'none' : 'block';

  try {
    const res = await fetch(`https://equran.id/api/v2/surat/${nomorSurat}`);
    const { data } = await res.json();

    suratAktifInfo = { nomor: data.nomor, namaLatin: data.namaLatin, jumlahAyat: data.jumlahAyat };

    // Jika belum ada audio yang berputar, muat daftar ayat surat ini ke pemutar
    if (audio.paused && indeksAyatDiputar === -1) {
      daftarAyatAktif = data.ayat;
      suratSedangDiputar = suratAktifInfo;
    }

    document.getElementById('judulBacaSurat').textContent = `${data.nomor}. ${data.namaLatin}`;
    document.getElementById('subBacaSurat').textContent = `${data.arti} • ${data.jumlahAyat} Ayat`;

    simpanHistory(data.nomor, data.namaLatin, ayatTujuan);

    wadahAyat.innerHTML = '';
    data.ayat.forEach((a, idx) => {
      const div = document.createElement('div');
      div.className = 'kartu-ayat';
      div.id = `kartu-ayat-${idx}`;
      if (suratSedangDiputar && suratSedangDiputar.nomor === data.nomor && indeksAyatDiputar === idx) {
        div.classList.add('ayat-aktif');
      }

      div.innerHTML = `
        <div class="ayat-header">
          <span class="badge-ayat">Ayat ${a.nomorAyat}</span>
          <button class="btn-audio-ayat btn-interaktif" onclick="mulaiPutarSuratIni(${idx}, false)">Putar Ayat</button>
        </div>
        <div class="arab-besar">${a.teksArab}</div>
        <div class="latin-teks">${a.teksLatin}</div>
        <div class="arti-teks">${a.teksIndonesia}</div>
      `;
      wadahAyat.appendChild(div);
    });

    if (ayatTujuan > 1) {
      const target = document.getElementById(`kartu-ayat-${ayatTujuan - 1}`);
      if (target) target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  } catch (e) {
    wadahAyat.innerHTML = `<div class="status-teks">Gagal memuat surat. Periksa koneksi internet.</div>`;
  }
}

function tutupBacaSurat() {
  // Suara tetap lanjut diputar meskipun kembali ke daftar surat
  document.getElementById('quran-read-mode').style.display = 'none';
  document.getElementById('quran-list-mode').style.display = 'block';
}

// Memastikan daftar ayat yang diputar adalah surat yang sedang dibuka user
async function mulaiPutarSuratIni(indexAwal, beruntun = true) {
  if (suratAktifInfo) {
    const res = await fetch(`https://equran.id/api/v2/surat/${suratAktifInfo.nomor}`);
    const { data } = await res.json();
    daftarAyatAktif = data.ayat;
    suratSedangDiputar = { nomor: data.nomor, namaLatin: data.namaLatin };
  }
  putarDariAyat(indexAwal, beruntun);
}

function putarSatuSuratPenuh() {
  if (sedangPutarBeruntun && suratSedangDiputar?.nomor === suratAktifInfo?.nomor) {
    hentikanSemuaAudio();
    return;
  }
  mulaiPutarSuratIni(0, true);
}

function putarDariAyat(index, beruntun = true) {
  if (index >= daftarAyatAktif.length) {
    hentikanSemuaAudio();
    return;
  }

  sedangPutarBeruntun = beruntun;
  indeksAyatDiputar = index;

  const ayatObj = daftarAyatAktif[index];
  const sedangDiHalamanBaca = document.getElementById('view-quran').classList.contains('aktif') &&
                              document.getElementById('quran-read-mode').style.display === 'block' &&
                              suratAktifInfo?.nomor === suratSedangDiputar?.nomor;

  // Sorot & scroll ayat HANYA jika user sedang berada di halaman baca surat tersebut
  document.querySelectorAll('.kartu-ayat.ayat-aktif').forEach(el => el.classList.remove('ayat-aktif'));
  if (sedangDiHalamanBaca) {
    const kartuAktif = document.getElementById(`kartu-ayat-${index}`);
    if (kartuAktif) {
      kartuAktif.classList.add('ayat-aktif');
      kartuAktif.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }

  const btnAll = document.getElementById('btnPutarSemua');
  if (btnAll) {
    btnAll.textContent = `Hentikan (Ayat ${index + 1})`;
    btnAll.classList.add('sedang-jalan');
  }

  // Tampilkan Mini Player melayang agar bisa dikontrol dari menu mana pun
  const miniPlayer = document.getElementById('miniPlayer');
  const miniJudul = document.getElementById('miniJudul');
  const btnMiniPause = document.getElementById('btnMiniPause');
  if (miniPlayer && suratSedangDiputar) {
    miniPlayer.style.display = 'flex';
    miniJudul.textContent = `QS. ${suratSedangDiputar.namaLatin} • Ayat ${ayatObj.nomorAyat}`;
    btnMiniPause.textContent = 'Jeda';
  }

  simpanHistory(suratSedangDiputar.nomor, suratSedangDiputar.namaLatin, ayatObj.nomorAyat);

  audio.src = ayatObj.audio['05'] || Object.values(ayatObj.audio)[0];
  audio.play();

  audio.onended = () => {
    if (sedangPutarBeruntun && index + 1 < daftarAyatAktif.length) {
      putarDariAyat(index + 1, true);
    } else {
      hentikanSemuaAudio();
    }
  };
}

function togglePauseAudio() {
  const btnMiniPause = document.getElementById('btnMiniPause');
  if (audio.paused) {
    audio.play();
    btnMiniPause.textContent = 'Jeda';
  } else {
    audio.pause();
    btnMiniPause.textContent = 'Lanjut';
  }
}

function bukaKembaliSuratDiputar() {
  if (suratSedangDiputar) {
    bukaMenu('quran');
    bukaBacaSurat(suratSedangDiputar.nomor, indeksAyatDiputar + 1);
  }
}

function hentikanSemuaAudio() {
  sedangPutarBeruntun = false;
  indeksAyatDiputar = -1;
  audio.pause();
  audio.currentTime = 0;
  document.querySelectorAll('.kartu-ayat.ayat-aktif').forEach(el => el.classList.remove('ayat-aktif'));

  const btnAll = document.getElementById('btnPutarSemua');
  if (btnAll) {
    btnAll.textContent = 'Putar 1 Surat';
    btnAll.classList.remove('sedang-jalan');
  }

  const miniPlayer = document.getElementById('miniPlayer');
  if (miniPlayer) miniPlayer.style.display = 'none';
}

// ==========================================
// 5. DOA-DOA & TUNTUNAN SHOLAT
// ==========================================
function renderDoaMuslim() {
  const wadah = document.getElementById('wadahDoa');
  wadah.innerHTML = DATA_DOA_MUSLIM.map(d => `
    <div class="kartu-materi">
      <h4>${d.judul}</h4>
      <div class="arab-besar">${d.arab}</div>
      <div class="latin-teks">${d.latin}</div>
      <div class="arti-teks">Artinya: "${d.arti}"</div>
    </div>
  `).join('');
}

function tampilkanTuntunanSholat(jenis) {
  document.getElementById('btnSholatWajib').classList.toggle('aktif', jenis === 'wajib');
  document.getElementById('btnSholatSunnah').classList.toggle('aktif', jenis === 'sunnah');

  const daftarNiat = DATA_TUNTUNAN_SHOLAT[jenis];
  const gerakan = DATA_TUNTUNAN_SHOLAT.gerakanLengkap;

  const htmlNiat = daftarNiat.map(item => `
    <div class="kartu-materi">
      <h4>${item.judul}</h4>
      <div class="arab-besar">${item.arab}</div>
      <div class="latin-teks">${item.latin}</div>
      <div class="arti-teks">${item.arti}</div>
    </div>
  `).join('');

  const htmlGerakan = gerakan.map(g => `
    <div class="kartu-materi">
      <h4>${g.judul}</h4>
      <div class="arab-besar">${g.arab}</div>
      <div class="latin-teks">${g.latin}</div>
      <div class="arti-teks">${g.arti}</div>
    </div>
  `).join('');

  document.getElementById('wadahTuntunanSholat').innerHTML = `
    <h3 style="color:var(--aksen-sekunder); font-size:0.95rem; margin-top:4px;">A. Bacaan Niat</h3>
    ${htmlNiat}
    <h3 style="color:var(--aksen-sekunder); font-size:0.95rem; margin-top:10px;">B. Urutan Bacaan dari Takbir sampai Salam</h3>
    ${htmlGerakan}
  `;
}

// ==========================================
// 6. RIWAYAT BACAAN (HISTORY DI LOCALSTORAGE)
// ==========================================
function simpanHistory(nomorSurat, namaSurat, ayat) {
  const waktu = new Date().toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' });
  let riwayat = JSON.parse(localStorage.getItem('riwayatQuran') || '[]');

  riwayat = riwayat.filter(item => item.nomorSurat !== nomorSurat);
  riwayat.unshift({ nomorSurat, namaSurat, ayat, waktu });

  if (riwayat.length > 15) riwayat.pop();
  localStorage.setItem('riwayatQuran', JSON.stringify(riwayat));
  updateBannerBeranda();
}

function updateBannerBeranda() {
  const riwayat = JSON.parse(localStorage.getItem('riwayatQuran') || '[]');
  const teks = document.getElementById('teksTerakhirBaca');
  const btn = document.getElementById('btnLanjutBaca');

  if (riwayat.length > 0) {
    const terakhir = riwayat[0];
    teks.textContent = `QS. ${terakhir.namaSurat} • Ayat ${terakhir.ayat}`;
    btn.style.display = 'inline-block';
    btn.onclick = () => {
      bukaMenu('quran');
      bukaBacaSurat(terakhir.nomorSurat, terakhir.ayat);
    };
  } else {
    teks.textContent = 'Belum ada riwayat bacaan';
    btn.style.display = 'none';
  }
}

function renderHistory() {
  const riwayat = JSON.parse(localStorage.getItem('riwayatQuran') || '[]');
  const wadah = document.getElementById('wadahHistory');

  if (riwayat.length === 0) {
    wadah.innerHTML = `<div class="status-teks">Belum ada catatan bacaan. Mulai baca Al-Qur'an untuk menyimpan riwayat otomatis.</div>`;
    return;
  }

  wadah.innerHTML = riwayat.map(r => `
    <div class="kartu-daftar btn-interaktif" onclick="bukaMenu('quran'); bukaBacaSurat(${r.nomorSurat}, ${r.ayat});">
      <div>
        <strong style="color:var(--aksen-sekunder);">QS. ${r.namaSurat} (Ayat ${r.ayat})</strong><br>
        <small style="color:var(--teks-redup); font-size:0.75rem;">Dibaca pada ${r.waktu}</small>
      </div>
      <span style="color:var(--aksen-utama); font-size:0.82rem; font-weight:600;">Lanjut →</span>
    </div>
  `).join('');
}

function hapusSemuaHistory() {
  localStorage.removeItem('riwayatQuran');
  updateBannerBeranda();
  renderHistory();
}

// ==========================================
// INISIALISASI AWAL APLIKASI
// ==========================================
inisialisasiTema();
muatJadwalSholat();
muatDaftarSurat();
renderDoaMuslim();
tampilkanTuntunanSholat('wajib');
updateBannerBeranda();